#include <QApplication>
#include "securewidget.h"
#include "screenshothandler.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    SecureWidget window;
    window.resize(800, 600);
    window.show();

    ScreenshotHandler handler;
    handler.monitorScreenCapture(&window);

    return app.exec();
}
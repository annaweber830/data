#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>

#include <gdk-pixbuf/gdk-pixbuf.h>
#include <gdk/gdk.h>

#include <X11/Xlib.h>
#include <X11/extensions/Xcomposite.h>
#include <X11/extensions/Xrender.h>
#include <X11/extensions/Xfixes.h>
#include <X11/extensions/shape.h>


typedef GVariant* (*g_dbus_connection_call_sync_t)(GDBusConnection *, const gchar *, const gchar *, const gchar *, const gchar *, GVariant *, const GVariantType *, GDBusCallFlags, gint, GCancellable *, GError **);

GVariant* g_dbus_connection_call_sync(GDBusConnection  *connection, const gchar *bus_name, const gchar *object_path,
                                const gchar *interface_name, const gchar *method_name, GVariant *parameters,
                                 const GVariantType *reply_type, GDBusCallFlags flags, gint timeout, GCancellable *cancellable, GError **error)
{
    if (bus_name && strcmp(bus_name, "org.gnome.Shell.Screenshot") == 0)
    {
        printf("[Block] Screenshot attempt detected via DBus!\n");
        return 0; // Block the request
    }

    g_dbus_connection_call_sync_t original = (g_dbus_connection_call_sync_t)dlsym(RTLD_NEXT, "g_dbus_connection_call_sync");
    return original(connection, bus_name, object_path, interface_name, method_name, parameters, reply_type, flags, timeout, cancellable, error);
}


// Original function pointer
static GdkPixbuf* (*orig_gdk_pixbuf_get_from_window)(GdkWindow*, gint, gint, gint, gint) = NULL;

GdkPixbuf* gdk_pixbuf_get_from_window(GdkWindow *window, gint src_x, gint src_y, gint width, gint height) {
    printf("[BLOCK] gdk_pixbuf_get_from_window() called - Screenshot blocked!\n");
    return NULL;  // Prevent screenshot capture
}

// Hook other functions
static GdkPixbuf* (*orig_gdk_window_get_pixbuf)(GdkWindow*) = NULL;
GdkPixbuf* gdk_window_get_pixbuf(GdkWindow *window) {
    printf("[BLOCK] gdk_window_get_pixbuf() called - Screenshot blocked!\n");
    return NULL;
}

// Hook XGetImage
typedef XImage* (*XGetImage_t)(Display *, Drawable, int, int, unsigned int, unsigned int, unsigned long, int);
XGetImage_t original_XGetImage = NULL;
XImage* XGetImage(Display *display, Drawable d, int x, int y, unsigned int width, unsigned int height, unsigned long plane_mask, int format) {
    printf("[BLOCK] XGetImage attempted!\n");
    return NULL;
}

// Hook XShmGetImage
typedef XImage* (*XShmGetImage_t)(Display *, Drawable, XImage *, int, int, unsigned long);
XShmGetImage_t original_XShmGetImage = NULL;
XImage* XShmGetImage(Display *display, Drawable d, XImage *image, int x, int y, unsigned long plane_mask) {
    printf("[BLOCK] XShmGetImage attempted!\n");
    return NULL;
}

// Hook XCompositeNameWindowPixmap
typedef Pixmap (*XCompositeNameWindowPixmap_t)(Display *, Window);
XCompositeNameWindowPixmap_t original_XCompositeNameWindowPixmap = NULL;
Pixmap XCompositeNameWindowPixmap(Display *display, Window window) {
    printf("[BLOCK] XCompositeNameWindowPixmap attempted!\n");
    return 0; // Return an invalid Pixmap
}

// Hook XRenderComposite
//typedef void (*XRenderComposite_t)(Display *, int, Picture, Picture, Picture, int, int, int, int, int, int, unsigned int, unsigned int);
//XRenderComposite_t original_XRenderComposite = NULL;
//void XRenderComposite(Display *dpy, int op, Picture src, Picture mask, Picture dst, int src_x, int src_y, int mask_x, int mask_y, int dst_x, int dst_y, unsigned int width, unsigned int height) {
//    printf("[BLOCK] XRenderComposite attempted!\n");
//    if (original_XRenderComposite)
//        original_XRenderComposite(dpy, op, src, mask, dst, src_x, src_y, mask_x, mask_y, dst_x, dst_y, width, height);
//}

// Hook XFixesGetCursorImage
typedef XFixesCursorImage* (*XFixesGetCursorImage_t)(Display *);
XFixesGetCursorImage_t original_XFixesGetCursorImage = NULL;
XFixesCursorImage* XFixesGetCursorImage(Display *display) {
    printf("[BLOCK] XFixesGetCursorImage attempted!\n");
    return NULL;
}

// Hook XShapeGetRectangles
typedef XRectangle* (*XShapeGetRectangles_t)(Display *, Window, int, int *, int *);
XShapeGetRectangles_t original_XShapeGetRectangles = NULL;
XRectangle* XShapeGetRectangles(Display *display, Window w, int kind, int *count, int *ordering_return) {
    printf("[BLOCK] XShapeGetRectangles attempted!\n");
    return NULL;
}

// Initialization Hook
__attribute__((constructor)) void init() {
    original_XGetImage = (XGetImage_t)dlsym(RTLD_NEXT, "XGetImage");
    original_XShmGetImage = (XShmGetImage_t)dlsym(RTLD_NEXT, "XShmGetImage");
    original_XCompositeNameWindowPixmap = (XCompositeNameWindowPixmap_t)dlsym(RTLD_NEXT, "XCompositeNameWindowPixmap");
//    original_XRenderComposite = (XRenderComposite_t)dlsym(RTLD_NEXT, "XRenderComposite");
    original_XFixesGetCursorImage = (XFixesGetCursorImage_t)dlsym(RTLD_NEXT, "XFixesGetCursorImage");
    original_XShapeGetRectangles = (XShapeGetRectangles_t)dlsym(RTLD_NEXT, "XShapeGetRectangles");

    orig_gdk_pixbuf_get_from_window = dlsym(RTLD_NEXT, "gdk_pixbuf_get_from_window");
    orig_gdk_window_get_pixbuf = dlsym(RTLD_NEXT, "gdk_window_get_pixbuf");

    printf("X11 Screenshot Blocking Hooks Installed!\n");
}


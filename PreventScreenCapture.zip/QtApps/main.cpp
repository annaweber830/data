#include "mainwindow.h"
#include <QApplication>

#include <windows.h>

typedef BOOL (WINAPI *SWDA)(HWND, DWORD);

void preventScreenCapture(WId winId) {
    HWND hwnd = reinterpret_cast<HWND>(winId);
//    SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE); // Prevent screen capture

    HMODULE hUser32 = LoadLibrary(L"user32.dll");
    if (!hUser32) return;

    SWDA pSetWindowDisplayAffinity = (SWDA)GetProcAddress(hUser32, "SetWindowDisplayAffinity");
    if (pSetWindowDisplayAffinity) {
        pSetWindowDisplayAffinity(hwnd, 1);  // WDA_MONITOR or 1 (Prevents screen capture)
    }

    FreeLibrary(hUser32);
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    preventScreenCapture(w.winId()); // Apply protection
    return a.exec();
}

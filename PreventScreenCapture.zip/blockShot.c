#define _GNU_SOURCE
#include <X11/Xlib.h>
#include <dlfcn.h>
#include <stdio.h>

#include <X11/extensions/Xcomposite.h>

#include <X11/extensions/XShm.h>
#include <stdio.h>
#include <dlfcn.h>


typedef void (*XCompositeRedirectWindow_t)(Display *, Window, int);
XCompositeRedirectWindow_t original_XCompositeRedirectWindow = NULL;

void XCompositeRedirectWindow(Display *dpy, Window window, int update)
{
    printf("[Block] XComposite capture attempt detected!\n");
    return;  // Block screen capture
}


#include <X11/extensions/Xrandr.h>

typedef XRRScreenResources *(*XRRGetScreenResources_t)(Display *, Window);
XRRGetScreenResources_t original_XRRGetScreenResources = NULL;

XRRScreenResources *XRRGetScreenResources(Display *dpy, Window window)
{
    printf("[Block] Xrandr screenshot attempt detected!\n");
    return NULL;  // Block screen capture
}

//// Function pointer for original XGetImage
//typedef XImage *(*XGetImage_t)(Display *, Drawable, int, int, unsigned int, unsigned int, unsigned long, int);

//// Get the original function
//XGetImage_t original_XGetImage = NULL;

//// Hook function to replace XGetImage
//XImage *XGetImage(Display *display, Drawable d, int x, int y, unsigned int width, unsigned int height, unsigned long plane_mask, int format)
//{
//    printf("[Block] Screenshot attempt detected!\n");
//    return NULL; // Return NULL to block screenshot
//}

//// Constructor function to initialize hooking
//__attribute__((constructor)) void init()
//{
//    original_XGetImage = (XGetImage_t)dlsym(RTLD_NEXT, "XGetImage");
//    if (!original_XGetImage)
//    {
//        printf("Error: Could not find original XGetImage\n");
//    }
//    else
//    {
//        printf("XGetImage Hooked! Screenshots blocked.\n");
//    }
//}

typedef Bool (*XShmGetImage_t)(Display *, Drawable, XImage *, int, int, unsigned long);
XShmGetImage_t original_XShmGetImage = NULL;

Bool XShmGetImage(Display *display, Drawable d, XImage *image, int x, int y, unsigned long plane_mask)
{
    printf("[Block] XShmGetImage capture attempt detected!\n");
    return False;  // Block screenshots
}

__attribute__((constructor)) void init()
{
    original_XShmGetImage = (XShmGetImage_t)dlsym(RTLD_NEXT, "XShmGetImage");
    if (!original_XShmGetImage)
    {
        printf("Error: Could not find original XShmGetImage\n");
    }
    else
    {
        printf("XShmGetImage Hooked! Screenshots blocked.\n");
    }
}

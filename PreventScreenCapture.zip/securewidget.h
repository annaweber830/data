#ifndef SECUREWIDGET_H
#define SECUREWIDGET_H

#include <QWidget>

class SecureWidget : public QWidget
{
    Q_OBJECT

public:
    explicit SecureWidget(QWidget *parent = nullptr);

    void setCaptureActive(bool active);

protected:
    void paintEvent(QPaintEvent *event) override;
    void showEvent(QShowEvent *event) override;

private:
    void updateContents();
    bool m_isCaptureActive;
};

#endif // SECUREWIDGET_H
#include "screenshothandler.h"
#include "securewidget.h"
#include <QTimer>
#include <QX11Info>
#include <QDebug>
#include <QProcess>

ScreenshotHandler::ScreenshotHandler(QObject *parent) : QObject(parent), m_widget(nullptr)
{
#ifdef Q_OS_UNIX
    m_display = QX11Info::display();
    m_rootWindow = DefaultRootWindow(m_display);
    if (!XDamageQueryExtension(m_display, &m_damageEventBase, &m_damageErrorBase)) {
        qWarning() << "XDamage extension not available";
    } else {
        XDamageCreate(m_display, m_rootWindow, XDamageReportNonEmpty);
    }
#endif
}

void ScreenshotHandler::monitorScreenCapture(QWidget *widget)
{
    m_widget = widget;
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &ScreenshotHandler::checkForScreenCapture);
    timer->start(1000); // Check every second
}

void ScreenshotHandler::checkForScreenCapture()
{
    checkForKnownScreenCaptureTools();
    checkForXDamageEvents();
}

void ScreenshotHandler::checkForKnownScreenCaptureTools()
{
    QStringList screenCaptureTools = {"gnome-screenshot", "shutter", "flameshot"};
    QProcess process;
    process.start("ps", QStringList() << "aux");
    process.waitForFinished();
    QString output = process.readAllStandardOutput();

    bool captureDetected = false;
    for (const QString &tool : screenCaptureTools) {
        if (output.contains(tool)) {
            qDebug() << "Screen capture tool detected:" << tool;
            captureDetected = true;
            break;
        }
    }

    if (captureDetected) {
        static_cast<SecureWidget*>(m_widget)->setCaptureActive(true);
    } else {
        static_cast<SecureWidget*>(m_widget)->setCaptureActive(false);
    }
}

void ScreenshotHandler::checkForXDamageEvents()
{
#ifdef Q_OS_UNIX
    XEvent event;
    while (XPending(m_display)) {
        XNextEvent(m_display, &event);
        if (event.type == m_damageEventBase + XDamageNotify) {
            XDamageNotifyEvent *damageEvent = reinterpret_cast<XDamageNotifyEvent*>(&event);
            if (damageEvent->drawable == m_rootWindow) {
                qDebug() << "Screen capture detected via XDamage";
                static_cast<SecureWidget*>(m_widget)->setCaptureActive(true);
                return;
            }
        }
    }
    static_cast<SecureWidget*>(m_widget)->setCaptureActive(false);
#endif
}
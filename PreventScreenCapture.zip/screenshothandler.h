#ifndef SCREENSHOTHANDLER_H
#define SCREENSHOTHANDLER_H

#include <QObject>
#include <QWidget>
#ifdef Q_OS_UNIX
#include <X11/Xlib.h>
#include <X11/extensions/Xdamage.h>
#endif

class ScreenshotHandler : public QObject
{
    Q_OBJECT

public:
    explicit ScreenshotHandler(QObject *parent = nullptr);
    void monitorScreenCapture(QWidget *widget);

private:
    QWidget *m_widget;
#ifdef Q_OS_UNIX
    Display *m_display;
    Window m_rootWindow;
    int m_damageEventBase;
    int m_damageErrorBase;

    void checkForScreenCapture();
    void checkForKnownScreenCaptureTools();
    void checkForXDamageEvents();
#endif
};

#endif // SCREENSHOTHANDLER_H
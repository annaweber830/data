#include "securewidget.h"
#include <QPainter>

SecureWidget::SecureWidget(QWidget *parent) : QWidget(parent), m_isCaptureActive(false)
{
    setAttribute(Qt::WA_NoSystemBackground, true);
    setAttribute(Qt::WA_TranslucentBackground, true);
}

void SecureWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    if (m_isCaptureActive) {
        painter.fillRect(rect(), Qt::black); // Draw black when hiding content
    } else {
        updateContents(); // Draw actual content
    }
}

void SecureWidget::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    if (!m_isCaptureActive) {
        updateContents();
    }
}

void SecureWidget::updateContents()
{
    QPainter painter(this);
    painter.fillRect(rect(), Qt::white); // Example content
    painter.drawText(rect(), Qt::AlignCenter, "Secure Content");
}

void SecureWidget::setCaptureActive(bool active)
{
    m_isCaptureActive = active;
    update();
}